<?php
include_once('php/allFunctions.php');

  
 // if(isset($_POST['find_content']))
 //   {
 //      $category_id=$_POST['category'];
 //      $subcategory_id=$_POST['subcategory'];
      
 //       $result = getContents($category_id,$subcategory_id);

 //      if(!$result){

 //       $msg= "Not found !!";
 //    }
  
 //       header('Location: '.$_SERVER['HTTP_REFERER']);
 //       return $result;
 //  }


   ?>