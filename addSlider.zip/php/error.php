<!DOCTYPE html>
<html>
<head>
	<title>ERROR - Not Found!</title>

	<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css" media="screen" />
	<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script> 

</head>
<body>
<div class="container" style="height: 100vh; margin: 200px 0px 0px 100px">
	<div class="jumbotron">
	    <h3>SWOTTA</h3>
		<h1>ERROR 404: Webpage Not Found</h1>
	</div>
</div>
</body>
</html>